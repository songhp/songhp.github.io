function [xt out] = EMTP(A, y, k, varargin)
% EMTP: Expectation conditinal Maximazation either Thresholding Pursuit
% Coded by Heping Song (hepingsong@gmail.com)
% 
%%%%%%%%%%%%%%%%%% input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT(compulsory):
%   A: m*n measurement matrix
%   y: m*1 measurements
%   k: sparsity level
%   
%%%%%%%%%%%%%%%%%% output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   xt: reconstructed sparse signal
%   out.iter: number of iterations


maxit = 100; 
Tolerance = 1e-10; % convergence tolerance

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('Tolerance')
                Tolerance=varargin{i+1};  
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end


n = size(A,2); % signal length

% initialization
t = 1; % iteration number
xt = zeros(n,1);  % initial x
% xt = pinv(A)*y; % initial x
r = y;  % initial residue
support_size = k;  % initial sparsity level
stop = 0; % not convergent

AA = pinv(A);
while ~stop

    % support detection
    [val idx] = sort(abs(xt +  AA *r), 'descend');
	support = sort(idx(1:support_size));
    
    % signal estimation
    xt = zeros(n,1);
    xt(support) = pinv(A(:, support)) * y;
    r = y - A*xt;    

	if  norm(r)/norm(y) < Tolerance  || t > maxit
        stop = 1; % convergent
    else
        t = t+1;
    end
    

end
fprintf('\n'); 



% output
out.iter = t;