function  [x,Out] = EMTPgamma(A, y, gamma, varargin)
% EMTP: Expectation conditinal Maximazation either Thresholding Pursuit
% Coded by Heping Song (hepingsong@gmail.com)
% 
%%%%%%%%%%%%%%%%%% input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT(compulsory):
%   A:       m*n measurement matrix
%   y:       m*1 measurements
%   gamma:   thresholding parameter
%   
%%%%%%%%%%%%%%%%%% output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   xt: reconstructed sparse signal
%   out.iter: number of iterations


maxit = 100;
Tolerance = 1e-6; % convergence tolerance

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('Tolerance')
                Tolerance=varargin{i+1};  
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end


[m, n] = size(A);

t = 0;
x= zeros(n, 1);
r = y;
stop = 0;
AA = pinv(A);
support = [];

while ~stop

    % support detection
    actfun = AA * r + x;
    T = setdiff([1:n], support);
    actfun = actfun(T);
    [activeset, val] = find(abs(actfun) > gamma * max(abs(actfun)));
    support = union(support, T(activeset));
    
    % signal estimation
    x = zeros(n,1);
    x(support) = pinv(A(:, support)) * y;
    r = y - A*x; 
    

	if  norm(r)/norm(y) < Tolerance  || t > maxit
        stop = 1; % convergence tolerance
    else
        t = t + 1;
    end

end    
Out.iter=t;

